//requires
var http = require('http');
var filesystem = require('fs');
var DSDUBData = require('./DSDUDB.js');


//globals
var DSDUDatabase  = new DSDUBData();



//Create a server
var server = http.createServer(handleRequest);
var PORT = 3030;

//read describe_API data from file
var desc_API = filesystem.readFileSync('dsduapi.data');


//Lets start our server
server.listen(PORT,  "0.0.0.0", function(){
    //Callback triggered when server is successfully listening. Hurray!
    console.log("DSDU Server listening on PORT %s, call GET /describe_API for further info.", PORT);
});


var dispatcher = require('httpdispatcher');


function handleRequest(request, response){
    try {
        //log the request on console
        console.log(request.url);
        //Disptach
        dispatcher.dispatch(request, response);
    } catch(err) {
        console.log(err);
    }
}


//For all your static (js/css/images/etc.) set the directory name (relative path).
dispatcher.setStatic('res');


//#IMPLEMENTED
//Esta função descreve a API, seus métodos e retornos. A descrição se encontra
//aberta em tempo de desenvolvimento, e deve ser bloqueada assim que o sistema
//estiver homologado  
dispatcher.onGet("/DSDU/describe_API", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain;charset=utf-8'});
    res.end(desc_API);
});
//----------------------------------------------------------------------------


//#TODO
//Esta função valida o direito de acesso de um determinado DSDU ao sistema.
//retorna o status dos DSDUS desabilitados/não acessíveis
dispatcher.onPost("/DSDU/DSDU_user_validate", function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain;charset=utf-8'});
    res.end('Got Post Data');
});
//--------------------------------------------------------------------------



//#IMPLEMENTED
//Esta função busca todos os usuários de um determinado pdv. Está devidamente implementada, devendo apenas ser integrado o sistema de validação por TOKEN

dispatcher.onPost("/DSDU/DSDU_up_data", function(req, res) {

res.setHeader('Access-Control-Allow-Origin', '*');
res.setHeader('Content-Type', 'text/plain;charset=utf-8');

    res.writeHead(200);

DSDUDatabase.create_reg(req.params);


//console.dir(req.params);
res.end('Dados Recebidos!');

});

//-------------------------------------------------------------------------


dispatcher.onPost("/DSDU/DSDU_gcm_register", function(req, res) {

res.setHeader('Access-Control-Allow-Origin', '*');
res.setHeader('Content-Type', 'text/plain;charset=utf-8');

    res.writeHead(200);

//DSDUDatabase.create_reg(req.params);


//console.dir(req.params);
res.end('{"ok":"ok"}');

});

//-------------------------------------------------------------------------
