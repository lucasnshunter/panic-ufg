GLOBAL.MongoClient = require('mongodb').MongoClient;
GLOBAL.DB = null;

var mongoURL = "mongodb://localhost:27017";
var mongoDBN = "DSDUDB";
                       

//SETUP DATABASE CON  ------------------------------------
function setDB(db){

	return MongoClient.connect(mongoURL+'/'+mongoDBN).then(function(db) {
		GLOBAL.DB = db;
		//console.log(GLOBAL.DB);
	});

};
//-------------------------------------------------------



//CONSTRUCTOR -------------------------------------------

function DSDUDatabase(){
	setDB();

};
//-------------------------------------------------------


//KILL DATABASE -----------------------------------------
function Die(){
	if (typeof(GLOBAL.DB) != undefined) {
		GLOBAL.DB.close();
	}
};
//------------------------------------------------------




//CRIA USUÁRIO NO DATABASE ----------------------------------------
DSDUDatabase.prototype.create_reg = function(params) {

	collection = GLOBAL.DB.collection('DSDU_EVENT');


collection.insert(params);


/*
	filter = {"phone": params.usrphone, "CPF": params.usrcpf };
	options  = { upsert: true };
	query = {"pvid": params.pdvid, "name": params.usrname, "phone": params.usrphone, "CPF": params.usrcpf, "address": params.usraddr, "area":params.usrarea, "bairro": params.usrbairro, "city":params.usradcit, "UF": params.usraduf, "CEP":params.usradcep, "STATUS":"OK", "insertTransactions": [{"Timestamp": 00000000, "PDV":params.pdvid, "Credits": 0}],"removeTransactions": [{"Timestamp":00000001, "PDV": params.pdvid, "Credits": 0}]};
	

	return collection.update(filter, query, options).then(function(items) {
		console.log(items);
		return items;
	});

*/
};
//-----------------------------------------------------------------





module.exports = DSDUDatabase;

