/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
	
	onWait();
	
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
      // var parentElement = document.getElementById(id);
       //var listeningElement = parentElement.querySelector('.listening');
      // var receivedElement = parentElement.querySelector('.received');

      // listeningElement.setAttribute('style', 'display:none;');
      // receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
	 
    }
};


var GPSRESULT;
var CAMRESULT;



var onGPSSuccess = function(position) {

GPSRESULT = position;

        //alert('Latitude: '          + position.coords.latitude          + '\n' +
        //      'Longitude: '         + position.coords.longitude         + '\n' +
        //      'Altitude: '          + position.coords.altitude          + '\n' +
        //      'Accuracy: '          + position.coords.accuracy          + '\n' +
        //      'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
        //      'Heading: '           + position.coords.heading           + '\n' +
        //      'Speed: '             + position.coords.speed             + '\n' +
        //      'Timestamp: '         + position.timestamp                + '\n');


navigator.camera.getPicture(onCAMSuccess, onCAMFail, { quality: 25,
   destinationType: Camera.DestinationType.DATA_URL
});

    };

    // onError Callback receives a PositionError object
    //
function onGPSError(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
}

function onWait() {
	//alert("fetching GPS data");

var options = { maximumAge: 30000, timeout: 27000, enableHighAccuracy: true };

	navigator.geolocation.getCurrentPosition(onGPSSuccess, onGPSError, options);


//navigator.camera.cleanup(function () {


//});


    }




function onCAMSuccess(imageData) {

CAMRESULT = btoa(imageData);

//alert(imageData);
   // var image = document.getElementById('image01');
   // image.src = "data:image/jpeg;base64," + imageData;

sendIT();

}

function onCAMFail(message) {
    alert('Failed because: ' + message);

sendIT();
}





     //alert('Latitude: '          + position.coords.latitude          + '\n' +
        //      'Longitude: '         + position.coords.longitude         + '\n' +
        //      'Altitude: '          + position.coords.altitude          + '\n' +
        //      'Accuracy: '          + position.coords.accuracy          + '\n' +
        //      'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
        //      'Heading: '           + position.coords.heading           + '\n' +
        //      'Speed: '             + position.coords.speed             + '\n' +
        //      'Timestamp: '         + position.timestamp                + '\n');


function sendIT() {

var http = new XMLHttpRequest();

var url = "http://162.243.215.24/DSDU/DSDU_up_data";
var params = "latitude="+GPSRESULT.coords.latitude+"&longitude="+GPSRESULT.coords.longitude+"&accuracy="+GPSRESULT.coords.accuracy+"&timestamp="+GPSRESULT.timestamp+"&picture="+CAMRESULT;
http.open("POST", url, true);

//Send the proper header information along with the request
//http.setRequestHeader('Access-Control-Allow-Origin', '*');
//http.setRequestHeader("Content-type", "text/plain;charset=utf-8");
http.setRequestHeader("Content-length", params.length);
//http.setRequestHeader("Connection", "close");

http.onreadystatechange = function() {//Call a function when the state changes.
	if(http.readyState == 4 && http.status == 200) {
		alert(http.responseText);
	}
}
http.send(params);




}



app.initialize();


